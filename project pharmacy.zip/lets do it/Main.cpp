#include<iostream>
#include<fstream>
#include<string>
#include<conio.h>

using namespace std;

struct node
{
	int id;
	string name;
	string fmla;
	string type;
	int price;
	int  mdate;
	int  m_month;
	int   myear;
	int  edate;
	int emonth;
	int  e_year;
	node* next = NULL;
};


class Linklist
{
public:

	node* head, * tail;

	Linklist()
	{
		tail = head = NULL;
	}

	void push_back(node* temp)////////////////////
	{
		if (temp == NULL) {
			cout << "\n===Link list over flow===\n";
			return;
		}


		if (head == NULL)
		{
			head = temp;	tail = temp;	temp = NULL;
		}
		else
		{
			tail->next = temp;	tail = temp;	temp = NULL;
		}

		cout << "\n----Data added----\n";
	}

	node* search(int id)
	{
		node* temp = head;
		while (temp != NULL)
		{
			if (temp->id == id)
			{
				cout << "\n----available---\n";
				return temp;
			}
			temp = temp->next;
		}
		cout << "\n----No Data Find----\n";
		return NULL;
	}

	node* del(int id)
	{
		node* back = head, * temp = head;
		while (temp != NULL)
		{
			if (temp->id == id)
			{
				if (head->next == NULL)
				{
					head = tail = NULL;
				}
				else if (head->id == temp->id)
				{
					head = head->next;
				}
				else
				{
					back->next = temp->next;
				}

				cout << "\n----Data Deleted----\n";
				return temp;
				break;
			}
			back = temp;
			temp = temp->next;
		}
		cout << "\n----No Data Find----\n";
		return(NULL);
	}

};




class Phr
{

public:
	Linklist L;
	Phr() {
	}


	void Input_new_Data()
	{
		node* temp = new node;
		cout << "Enter  New Medicine Id: ";
		cin >> temp->id;

		cout << "Enter  New Medicine Name: ";
		cin >> temp->name;

		cout << "Enter New Medicine formula: ";
		cin >> temp->fmla;

		cout << "Enter New Medicine type: ";
		cin >> temp->type;

		cout << "Enter Medicine Price: ";
		cin >> temp->price;

		cout << "Enter Medicine Manufacturer Date: ";
		cin >> temp->mdate;

		cout << "Enter Medicine Manufacturer Month: ";
		cin >> temp->m_month;

		cout << "Enter Medicine  Manufacturer Year: ";
		cin >> temp->myear;

		cout << "Enter Medicine Expiry Date: ";
		cin >> temp->edate;

		cout << "Enter Medicine Expiry Month: ";
		cin >> temp->emonth;

		cout << "Enter Medicine Expiry Year: ";
		cin >> temp->e_year;
		L.push_back(temp);
	}

	void display_single_data(node* temp)
	{

		cout << "\n\nMedicine Id: ";
		cout << temp->id;

		cout << "\nMedicine Name: ";
		cout << temp->name;

		cout << "\nMedicine formula: ";
		cout << temp->fmla;

		cout << "\nMedicine type: ";
		cout << temp->type;

		cout << "\nMedicine Price: ";
		cout << temp->price;

		cout << "\nMedicine Manufacturer Date: ";
		cout << temp->mdate;

		cout << "\nMedicine Manufacturer Month: ";
		cout << temp->m_month;

		cout << "\nMedicine Manufacturer Year: ";
		cout << temp->myear;

		cout << "\nMedicine Expiry Date: ";
		cout << temp->edate;

		cout << "\nMedicine Expiry Month: ";
		cout << temp->emonth;

		cout << "\nMedicine Expiry Year: ";
		cout << temp->e_year;
		cout << "\n\n";
	}

	void display_All_data()
	{
		node* temp = L.head;
		bool find = false;
		while (temp != NULL)
		{
			display_single_data(temp);
			temp = temp->next;
			find = true;
		}
		if (!find)
		{
			cout << "\n----Sorry no data available-----\n";
		}
	}

	void find()///whether medicine exist or not in file
	{
		int id;
		cout << "\nEnter the medicine id to find the record : ";
		cin >> id;
		node* temp = new node;
		temp = L.search(id);

		if (temp == NULL)	return;

		display_single_data(temp);
	}

	void update()
	{
		int id;
		cout << "\nEnter the medicine id to update the record : ";
		cin >> id;
		node* temp = new node;
		temp = L.search(id);


		if (temp == NULL)	return;
		display_single_data(temp);

		cout << "Enter  New Medicine Id: ";
		cin >> temp->id;

		cout << "Enter  New Medicine Name: ";
		cin >> temp->name;

		cout << "Enter New Medicine formula: ";
		cin >> temp->fmla;

		cout << "Enter New Medicine type: ";
		cin >> temp->type;

		cout << "Enter Medicine Price: ";
		cin >> temp->price;

		cout << "Enter Medicine Manufacturer Date: ";
		cin >> temp->mdate;

		cout << "Enter Medicine Manufacturer Month: ";
		cin >> temp->m_month;

		cout << "Enter Medicine  Manufacturer Year: ";
		cin >> temp->myear;

		cout << "Enter Medicine Expiry Date: ";
		cin >> temp->edate;

		cout << "Enter Medicine Expiry Month: ";
		cin >> temp->emonth;

		cout << "Enter Medicine Expiry Year: ";
		cin >> temp->e_year;

		cout << "\n\n---record-Updated---\n";
	}

	void del()
	{
		int id;
		cout << "\nEnter the Id of medicine you want to delete : ";
		cin >> id;

		node* temp = new node;
		temp = L.del(id);
		if (temp != NULL)
			display_single_data(temp);
	}
	void Read_file()
	{

		ifstream file;
		file.open("medicine detail.txt", ios::in);
		if ((!file) || file.eof() == true) { cout << "file not opening"; return; }

		else {
			cout << "\n file open\n--";

			while (true)
			{
				node* temp = new node;
				file >> temp->id;

				if (file.eof()) break;
				file >> temp->name;
				file >> temp->fmla;
				file >> temp->type;
				file >> temp->mdate;
				file >> temp->m_month;
				file >> temp->myear;
				file >> temp->edate;
				file >> temp->emonth;
				file >> temp->e_year;
				L.push_back(temp);
			}
			system("cls");
			file.close();
		}
	}

	void get_total_bill()
	{
		node* temp = L.head;
		int total = 0;
		bool find = true;
		if (temp == NULL)	find = false;

		while (temp != NULL)
		{
			total += temp->price;
			temp = temp->next;

		}

		if (find) {
			cout << "\n---Total is Bill of Stock = " << total << endl;
			return;
		}

		cout << "\n---No record find---\n";

	}
	void Write_file()
	{
		ofstream file;
		file.open("medicine detail.txt", ios::app);////////////////////////////////////////
		if ((!file) || file.eof() == true) { cout << "file not opening Data will be loss "; return; }////////////////////////

		else {
			node* temp = L.head;//////////////////////////////////
			while (temp != NULL)
			{
				file << temp->id << endl;
				file << temp->name << endl;
				file << temp->fmla << endl;
				file << temp->type << endl;
				file << temp->mdate << endl;
				file << temp->m_month << endl;
				file << temp->myear << endl;
				file << temp->edate << endl;
				file << temp->emonth << endl;
				file << temp->e_year << endl;
				temp = temp->next;
			}
			file.close();
			cout << "\n\n-----Data stored in file successfuly----\n";
		}

	}

};

void Menu()
{
	system("cls");
	cout << ".................................................";
	cout << endl;
	cout << "------------------Main Menu--------------------";
	cout << endl;
	cout << "||**** 1.Add new medicine                   ****||";
	cout << endl;
	cout << "||**** 2.Check total Stock                  ****||";
	cout << endl;
	cout << "||**** 3.Update medicine stock              ****||";
	cout << endl;
	cout << "||**** 4.Search Medicine stock              ****||";
	cout << endl;
	cout << "||**** 5.Delete medicine record             ****||";
	cout << endl;
	cout << "||**** 6.Print the Bill                     ****||";
	cout << endl;
	cout << "||**** 7.Exit                               ****||";
	cout << endl;
	cout << "..................................................";
	cout << "\nPlease Enter Choice: ";
}

int main() {

	Phr p;
	char ch;
	p.Read_file();
	while (true)
	{
		Menu();
		cin >> ch;
		switch (ch)
		{
		case '1':
			p.Input_new_Data();
			break;
		case '2':
			p.display_All_data();
			break;
		case '3':
			p.update();
			break;
		case '4':
			p.find();
			break;
		case '5':
			p.del();
			break;
		case '6':
			p.get_total_bill();
			break;
		case '7':
			
			p.Write_file();
			exit(1);

		default:
			cout << "\n---Invalid choise---\n";
		}
		cout << "\npress any key for Main Menu : ";
		int ch; cin >> ch;
	}
	return 0;

}















